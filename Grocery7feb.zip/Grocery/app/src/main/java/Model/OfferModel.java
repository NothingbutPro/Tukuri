package Model;

import java.io.Serializable;

public class OfferModel implements Serializable {

    private String offersId;
    private String description;
    private String image;

    public OfferModel(String offersId, String description, String image) {
        this.offersId = offersId;
        this.description = description;
        this.image = image;
    }

    public String getOffersId() {
        return offersId;
    }

    public void setOffersId(String offersId) {
        this.offersId = offersId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
