package com.tukuri.ics.Model;

public class Data {
    public int imageId;
    public String txt;

    Data( int imageId, String text) {

        this.imageId = imageId;
        this.txt=text;
    }
}