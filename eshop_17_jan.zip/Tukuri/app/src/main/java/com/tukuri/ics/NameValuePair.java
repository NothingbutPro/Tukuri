package com.tukuri.ics;

/**
 * Created by Raghav  2/6/2019.
 */

public class NameValuePair {
    public String name, value;

    public NameValuePair(String _name, String _value) {
        name = _name;
        value = _value;
    }
}
