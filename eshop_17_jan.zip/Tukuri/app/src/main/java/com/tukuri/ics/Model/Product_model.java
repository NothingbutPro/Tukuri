package com.tukuri.ics.Model;


public class Product_model {

    String product_id;
    String product_name;
    String product_description;
    String product_image;
    String category_id;
    String in_stock;
    String price;
    String unit_value;
    String unit;
    String increament;
    String title;
    String Mrp;

    String pack1;
    String pack2;
    String mrp1;
    String mrp2;
    String price1;
    String price2;


    public String getProduct_id() {
        return product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public String getProduct_description() {
        return product_description;
    }

    public String getProduct_image() {
        return product_image;
    }

    public String getCategory_id() {
        return category_id;
    }

    public String getIn_stock() {
        return in_stock;
    }

    public String getPrice() {
        return price;
    }

    public String getUnit_value() {
        return unit_value;
    }

    public String getUnit() {
        return unit;
    }


    public String getIncreament() {
        return increament;
    }

    public String getTitle() {
        return title;
    }

    public String getMrp() {
        return Mrp;
    }

    public String getPack1() {     return pack1;     }

    public String getPack2() {        return pack2;    }

    public String getMrp1() {        return mrp1;    }

    public String getMrp2() {        return mrp2;    }

    public String getPrice1() {        return price1;    }

    public String getPrice2() {        return price2;    }
}
